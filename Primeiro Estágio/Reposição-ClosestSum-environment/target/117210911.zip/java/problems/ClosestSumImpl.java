package problems;

import java.util.Arrays;

public class ClosestSumImpl implements ClosestSum {

	/**
	 * Restricoes: - voce nao pode usar nenhum metodo pronto de qualquer biblioteca.
	 */
	public ParIndices closestSum(Integer[] array, Integer x) {
		Integer elem1 = null;
		Integer elem2 = null;
		Integer[] aux = new Integer[array.length];
		aux = preencheListaSoma(array);
		// o floor irá retornar o primeiro indice do elemento mais proximo do elemento
		// ofertado
		int j = floor(aux, x);
		// percorre o array principal com o posicao da soma mais proxima(floor),
		// assim sendo, o par de elemento que estará mais proximo do elemento é o
		// dado cujo indice foi descoberto no floor e o anterior a ele, tendo em
		// vista a forma em que foi montado o array da somaDistancia.
		for (int i = 0; i < array.length; i++) {
			elem1 = array[j - 1];
			elem2 = array[j];
		}
		ParIndices result = new ParIndices(elem1, elem2);
		return result;

	}

	public Integer[] preencheListaSoma(Integer[] array) {
		int contador = 0;
		int indice = -1;
		Integer[] somaDist = new Integer[array.length];

		while (contador != array.length - 1) {
			contador++;
			indice++;
			somaDist[indice] = array[indice] + array[indice + 1];

		}
		return somaDist;
	}

	public static Integer floor(Integer[] array, int x) {
		Arrays.sort(array);
		return floor(array, x, 0, array.length);
	}

	private static Integer floor(Integer[] array, int x, int leftIndex, int rightIndex) {
		Integer result = null;
		if (leftIndex <= rightIndex) {
			int meio = (leftIndex + rightIndex) / 2;
			if (x == array[meio]) {
				result = meio;
			} else if (x < array[meio]) {
				if (meio > 0) {
					if (array[meio - 1] < x) {
						result = array[meio - 1];
					} else {
						result = floor(array, x, leftIndex, meio - 1);
					}
				}
			} else {
				if (leftIndex == rightIndex) {
					result = leftIndex;
				} else {
					result = floor(array, x, meio + 1, rightIndex);
				}
			}
		}
		return result;
	}

	public static Integer ceil(Integer[] array, int x) {
		Arrays.sort(array);
		return ceil(array, x, 0, array.length);
	}

	private static Integer ceil(Integer[] array, int x, int leftIndex, int rightIndex) {
		Integer result = null;
		if (leftIndex <= rightIndex) {
			int meio = (leftIndex + rightIndex) / 2;
			if (x == array[meio]) {
				result = meio;
			} else {
				if (leftIndex == rightIndex) {
					result = leftIndex;
				} else {
					result = ceil(array, x, meio + 1, rightIndex);
				}

			}
		}
		return result;
	}

}
